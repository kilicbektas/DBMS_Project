﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PostgreUrunProje
{
    public partial class FrmUrun : Form
    {
        public FrmUrun()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=dburunler; user ID=postgres; password=Hassecret93");
        private void BtnListele_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from urunler";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void BtnEkle_Click(object sender, EventArgs e)
        {

            baglanti.Open();
            NpgsqlCommand komut = new NpgsqlCommand("insert into urunler" +
            "(urunid,urunad,stok,alisfiyat,satisfiyat,gorsel,kategori,firma,marka) values " +
            "(@p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9)", baglanti);

            komut.Parameters.AddWithValue("@p1", int.Parse(TxtID.Text));
            komut.Parameters.AddWithValue("@p2", TxtAd.Text);
            komut.Parameters.AddWithValue("@p3", int.Parse(numericUpDown1.Value.ToString()));
            komut.Parameters.AddWithValue("@p4", double.Parse(TxtAlisFiyat.Text));
            komut.Parameters.AddWithValue("@p5", double.Parse(TxtSatisFiyat.Text));
            komut.Parameters.AddWithValue("@p6", TxtGorsel.Text);
            komut.Parameters.AddWithValue("@p7", int.Parse(comboBox1.SelectedValue.ToString()));
            komut.Parameters.AddWithValue("@p8", int.Parse(comboBox2.SelectedValue.ToString()));
            komut.Parameters.AddWithValue("@p9", int.Parse(comboBox3.SelectedValue.ToString()));
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("kayıt başarıyla oluşturuldu", "Bilgi" ,MessageBoxButtons.OK ,MessageBoxIcon.Information);
        }

        private void FrmUrun_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlDataAdapter kt = new NpgsqlDataAdapter("select * from kategoriler", baglanti);
            DataTable dtkt = new DataTable();
            kt.Fill(dtkt);
            comboBox1.DisplayMember = "kategoriad";
            comboBox1.ValueMember = "kategoriid";
            comboBox1.DataSource = dtkt;

            NpgsqlDataAdapter frm = new NpgsqlDataAdapter("select * from firmalar", baglanti);
            DataTable dtfrm = new DataTable();
            frm.Fill(dtfrm);
            comboBox2.DisplayMember = "kullaniciadi";
            comboBox2.ValueMember = "firmaid";
            comboBox2.DataSource = dtfrm;

            NpgsqlDataAdapter mrk = new NpgsqlDataAdapter("select * from markalar", baglanti);
            DataTable dtmrk = new DataTable();
            mrk.Fill(dtmrk);
            comboBox3.DisplayMember = "markaadi";
            comboBox3.ValueMember = "markaid";
            comboBox3.DataSource = dtmrk;

            baglanti.Close();
        }

        private void BtnSil_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut2 = new NpgsqlCommand("Delete from urunler where urunid=@p1", baglanti);
            komut2.Parameters.AddWithValue("@p1", int.Parse(TxtID.Text));
            komut2.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Silindi", "Bilgi" ,MessageBoxButtons.OK, MessageBoxIcon.Stop);


        }

        private void BtnGuncelle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update urunler set " +
                "urunad=@p1, stok=@p2, alisfiyat=@p3 where urunid=@p4", baglanti);
            komut3.Parameters.AddWithValue("@p1", TxtAd.Text);
            komut3.Parameters.AddWithValue("@p2", int.Parse(numericUpDown1.Value.ToString()));
            komut3.Parameters.AddWithValue("@p3", double.Parse(TxtAlisFiyat.Text));
            komut3.Parameters.AddWithValue("@p4", int.Parse(TxtID.Text));
            komut3.ExecuteNonQuery();
            MessageBox.Show("Güncellendi" ,"Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            baglanti.Close();
        }

        private void BtnView_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut4 = new NpgsqlCommand("Select * from urunlistesi", baglanti);

            NpgsqlDataAdapter da = new NpgsqlDataAdapter(komut4);
 
            DataSet dt = new DataSet();
            da.Fill(dt);
            dataGridView1.DataSource = dt.Tables[0];
 
            baglanti.Close();
        }

        private void BtnAra_Click(object sender, EventArgs e)
        {

        }
    }
}
