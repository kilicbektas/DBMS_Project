﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PostgreUrunProje
{
    public partial class Frmadmin : Form
    {
        public Frmadmin()
        {
            InitializeComponent();
        }

        private void TxtKullaniciAdi_TextChanged(object sender, EventArgs e)
        {
            TextBox txt = (sender as TextBox);
            txt.CharacterCasing = CharacterCasing.Upper;        
        }

        private void Frmadmin_Load(object sender, EventArgs e)
        {
            TxtSifre.PasswordChar = '*';
        }

        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=dburunler; user ID=postgres; password=Hassecret93");
        NpgsqlCommand komut;
        NpgsqlDataReader reader;
        private void BtnGiris_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            string sql = "select * from firmalar where kullaniciadi=@p1 and sifre=@p2 ;";
            string sql2 = "delete from onlinekullanici";
            string sql3 = "INSERT INTO onlinekullanici (onlineid, onlinekullaniciadi) SELECT firmaid, kullaniciadi FROM firmalar WHERE kullaniciadi="+ TxtKullaniciAdi.Text +" ;";
            komut = new NpgsqlCommand(sql, baglanti);
            
            komut.Parameters.AddWithValue("@p1", TxtKullaniciAdi.Text);
            komut.Parameters.AddWithValue("@p2", TxtSifre.Text);
            reader = komut.ExecuteReader();
            
            if(reader.Read())
            {

                komut = new NpgsqlCommand(sql2, baglanti);
                komut = new NpgsqlCommand(sql3, baglanti);

                MessageBox.Show("Giriş Başarılı", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.Information);
                FrmAnasayfa frm = new FrmAnasayfa();              
                frm.ShowDialog();
                Application.Exit();
            }
            else
            {
                MessageBox.Show("Hatalı Giriş", "Error" ,MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            baglanti.Close();
        }
    }
}
