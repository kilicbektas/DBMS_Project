--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: cirotoplama(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cirotoplama(a integer, b integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN a + b;
EXCEPTION
WHEN numeric_value_out_of_range THEN
-- do some important stuff
RETURN -1;
WHEN OTHERS THEN
-- do some other important stuff
RETURN -1;
END;
$$;


ALTER FUNCTION public.cirotoplama(a integer, b integer) OWNER TO postgres;

--
-- Name: firmaisimdegisikligi(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.firmaisimdegisikligi() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF NEW.onlinekullaniciadi <> OLD.onlinekullaniciadi THEN
		 INSERT INTO onlinekullanici(onlineid,onlinekullaniciadi)
		 VALUES(OLD.onlineid,OLD.onlinekullaniciadi);
	END IF;

	RETURN NEW;
END;
$$;


ALTER FUNCTION public.firmaisimdegisikligi() OWNER TO postgres;

--
-- Name: gelisfiyati -> satisfiyati(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."gelisfiyati -> satisfiyati"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
        -- Check that empname and salary are given
        IF NEW.empname IS NULL THEN
            RAISE EXCEPTION 'empname cannot be null';
        END IF;
        IF NEW.salary IS NULL THEN
            RAISE EXCEPTION '% cannot have null salary', NEW.empname;
        END IF;

        -- Who works for us when she must pay for it?
        IF NEW.salary < 0 THEN
            RAISE EXCEPTION '% cannot have a negative salary', NEW.empname;
        END IF;

        -- Remember who changed the payroll when
        NEW.last_date := current_timestamp;
        NEW.last_user := current_user;
        RETURN NEW;
    END;
$$;


ALTER FUNCTION public."gelisfiyati -> satisfiyati"() OWNER TO postgres;

--
-- Name: kaydet(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.kaydet() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."kullaniciadi" = UPPER(NEW."kullaniciadi"); 
    NEW."ContactName" = LTRIM(NEW."ContactName"); 
    IF NEW."City" IS NULL THEN
            RAISE EXCEPTION 'kullanıcı adı boş olamaz';  
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.kaydet() OWNER TO postgres;

--
-- Name: kullanicigirisi(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.kullanicigirisi() RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
result text;
BEGIN
PERFORM 'SELECT 1+1';
RETURN ’ok’;
END;
$$;


ALTER FUNCTION public.kullanicigirisi() OWNER TO postgres;

--
-- Name: personelara(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.personelara(personelno integer) RETURNS TABLE(numara integer, adi character varying, soyadi character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY SELECT "staff_id", "first_name", "last_name" FROM staff
                 WHERE "staff_id" = personelNo;
END;
$$;


ALTER FUNCTION public.personelara(personelno integer) OWNER TO postgres;

--
-- Name: satisfiyati_alisfiyati(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.satisfiyati_alisfiyati() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW."alisfiyati" <> OLD."alisfiyati" THEN
        INSERT INTO "UrunDegisikligiIzle"("urunNo", "eskiBirimFiyat", "yeniBirimFiyat", "degisiklikTarihi")
        VALUES(OLD."ProductID", OLD."UnitPrice", NEW."UnitPrice", CURRENT_TIMESTAMP::TIMESTAMP);
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.satisfiyati_alisfiyati() OWNER TO postgres;

--
-- Name: urunara(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.urunara(urun integer) RETURNS TABLE(urunid integer, adi character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY SELECT "urunid", "urunadi" FROM urunler
                 WHERE "urunid" = urunid;
END;
$$;


ALTER FUNCTION public.urunara(urun integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alicifirma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alicifirma (
    alicifirmaid integer NOT NULL,
    "alıcıkullaniciadi" character varying(10),
    sifre character varying(10),
    adres character varying(50)
);


ALTER TABLE public.alicifirma OWNER TO postgres;

--
-- Name: envanter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.envanter (
    urunid integer NOT NULL,
    urunad character varying(15),
    stok integer,
    alisfiyat double precision,
    satisfiyat double precision,
    kategorisi integer,
    markasi integer
);


ALTER TABLE public.envanter OWNER TO postgres;

--
-- Name: firmaciro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.firmaciro (
    id integer NOT NULL,
    gunlukciro double precision,
    aylikciro double precision,
    yillikciro double precision,
    firmaid integer
);


ALTER TABLE public.firmaciro OWNER TO postgres;

--
-- Name: firmalar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.firmalar (
    firmaid integer NOT NULL,
    kullaniciadi character varying(10),
    sifre character varying(10),
    adres character varying(50)
);


ALTER TABLE public.firmalar OWNER TO postgres;

--
-- Name: gelensiparis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gelensiparis (
    urunid integer NOT NULL,
    urunad character varying(30),
    adet integer,
    gelisfiyati double precision,
    satanfirma double precision,
    gelistarihi date,
    marka integer
);


ALTER TABLE public.gelensiparis OWNER TO postgres;

--
-- Name: iade; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iade (
    id integer NOT NULL,
    urunad character varying(20),
    adet integer,
    iadeedilecekfirma integer
);


ALTER TABLE public.iade OWNER TO postgres;

--
-- Name: kategoriler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kategoriler (
    kategoriid integer NOT NULL,
    kategoriad character varying(20)
);


ALTER TABLE public.kategoriler OWNER TO postgres;

--
-- Name: kisiler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kisiler (
    kisiid integer NOT NULL,
    kisiad character varying(15),
    kisisoyad character varying(15),
    kisikartno character varying(16),
    kisikarttarihi date,
    kisicvc character varying(3)
);


ALTER TABLE public.kisiler OWNER TO postgres;

--
-- Name: markalar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.markalar (
    markaid integer NOT NULL,
    markaadi character varying(15)
);


ALTER TABLE public.markalar OWNER TO postgres;

--
-- Name: onlinekullanici; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.onlinekullanici (
    onlineid integer NOT NULL,
    onlinekullaniciadi character varying(15)
);


ALTER TABLE public.onlinekullanici OWNER TO postgres;

--
-- Name: saticifirma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.saticifirma (
    firmaid integer NOT NULL,
    kullaniciadi character varying(10),
    sifre character varying(10),
    adres character varying(50)
);


ALTER TABLE public.saticifirma OWNER TO postgres;

--
-- Name: satis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.satis (
    satisurunid integer NOT NULL,
    urunadi character varying(15),
    adet integer,
    adetfiyati double precision,
    toplamfiyati double precision
);


ALTER TABLE public.satis OWNER TO postgres;

--
-- Name: telef; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telef (
    urunid integer NOT NULL,
    urunad character varying(30),
    adet integer,
    alisfiyat double precision,
    satisfiyat double precision,
    kategori integer,
    marka integer
);


ALTER TABLE public.telef OWNER TO postgres;

--
-- Name: urunler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.urunler (
    urunid integer NOT NULL,
    urunad character varying(30),
    stok integer,
    alisfiyat double precision,
    satisfiyat double precision,
    gorsel character varying(100),
    kategori integer,
    firma integer,
    marka integer
);


ALTER TABLE public.urunler OWNER TO postgres;

--
-- Name: urunlistesi; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.urunlistesi AS
 SELECT urunler.urunid,
    urunler.urunad,
    urunler.stok,
    urunler.alisfiyat,
    urunler.satisfiyat,
    urunler.gorsel,
    kategoriler.kategoriad,
    firmalar.kullaniciadi,
    markalar.markaadi
   FROM (((public.urunler
     JOIN public.kategoriler ON ((urunler.kategori = kategoriler.kategoriid)))
     JOIN public.firmalar ON ((urunler.firma = firmalar.firmaid)))
     JOIN public.markalar ON ((urunler.marka = markalar.markaid)));


ALTER TABLE public.urunlistesi OWNER TO postgres;

--
-- Data for Name: alicifirma; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: envanter; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: firmaciro; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: firmalar; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.firmalar VALUES (1, 'ESENAVM', 'esen123', 'istanbul');
INSERT INTO public.firmalar VALUES (2, 'BEKTASAVM', 'bektas123', 'sakarya');
INSERT INTO public.firmalar VALUES (3, 'GIZEMAVM', 'gizem123', 'sakarya');


--
-- Data for Name: gelensiparis; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: iade; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: kategoriler; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.kategoriler VALUES (1, 'Plastik');
INSERT INTO public.kategoriler VALUES (2, 'Züccaciye');
INSERT INTO public.kategoriler VALUES (3, 'Hırdavat');
INSERT INTO public.kategoriler VALUES (4, 'Oyuncak');
INSERT INTO public.kategoriler VALUES (5, 'Kırtasiye');
INSERT INTO public.kategoriler VALUES (6, 'Elektronik');
INSERT INTO public.kategoriler VALUES (7, 'Hediyelik');
INSERT INTO public.kategoriler VALUES (8, 'Bujiteri');
INSERT INTO public.kategoriler VALUES (9, 'Kozmetik');
INSERT INTO public.kategoriler VALUES (10, 'Elektrik');


--
-- Data for Name: kisiler; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: markalar; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.markalar VALUES (1, 'Faber-Castell');
INSERT INTO public.markalar VALUES (2, 'Mikro');
INSERT INTO public.markalar VALUES (3, 'Pensan');
INSERT INTO public.markalar VALUES (4, 'Fatih');
INSERT INTO public.markalar VALUES (5, 'PlayDoh');
INSERT INTO public.markalar VALUES (6, 'HobbyLife');
INSERT INTO public.markalar VALUES (7, 'Paşabahçe');
INSERT INTO public.markalar VALUES (8, 'İnci');
INSERT INTO public.markalar VALUES (9, 'meDalyan');
INSERT INTO public.markalar VALUES (10, 'korkmaz');
INSERT INTO public.markalar VALUES (11, 'Taç');
INSERT INTO public.markalar VALUES (12, 'Braun');
INSERT INTO public.markalar VALUES (13, 'Philips');


--
-- Data for Name: onlinekullanici; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: saticifirma; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: satis; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: telef; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: urunler; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.urunler VALUES (1, 'kurşun kalem', 50, 1, 2, 'kalem.jpg', 5, 1, 1);
INSERT INTO public.urunler VALUES (2, 'kova', 20, 10, 17, 'kova.jpg', 1, 1, 6);
INSERT INTO public.urunler VALUES (3, 'tencere', 10, 25, 50, 'tencere.jpg', 2, 3, 10);


--
-- Name: alicifirma alicifirma_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alicifirma
    ADD CONSTRAINT alicifirma_pkey PRIMARY KEY (alicifirmaid);


--
-- Name: envanter envanter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.envanter
    ADD CONSTRAINT envanter_pkey PRIMARY KEY (urunid);


--
-- Name: firmaciro firmaciro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.firmaciro
    ADD CONSTRAINT firmaciro_pkey PRIMARY KEY (id);


--
-- Name: firmalar firmalar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.firmalar
    ADD CONSTRAINT firmalar_pkey PRIMARY KEY (firmaid);


--
-- Name: gelensiparis gelensiparis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gelensiparis
    ADD CONSTRAINT gelensiparis_pkey PRIMARY KEY (urunid);


--
-- Name: iade iade_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iade
    ADD CONSTRAINT iade_pkey PRIMARY KEY (id);


--
-- Name: kategoriler kategoriler_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kategoriler
    ADD CONSTRAINT kategoriler_pkey PRIMARY KEY (kategoriid);


--
-- Name: kisiler kisiler_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kisiler
    ADD CONSTRAINT kisiler_pkey PRIMARY KEY (kisiid);


--
-- Name: markalar markalar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.markalar
    ADD CONSTRAINT markalar_pkey PRIMARY KEY (markaid);


--
-- Name: onlinekullanici onlinekullanici_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.onlinekullanici
    ADD CONSTRAINT onlinekullanici_pkey PRIMARY KEY (onlineid);


--
-- Name: saticifirma saticifirma_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saticifirma
    ADD CONSTRAINT saticifirma_pkey PRIMARY KEY (firmaid);


--
-- Name: satis satis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.satis
    ADD CONSTRAINT satis_pkey PRIMARY KEY (satisurunid);


--
-- Name: telef telef_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telef
    ADD CONSTRAINT telef_pkey PRIMARY KEY (urunid);


--
-- Name: urunler urunler_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.urunler
    ADD CONSTRAINT urunler_pkey PRIMARY KEY (urunid);


--
-- Name: fki_firmalar_girilenkullanici; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_firmalar_girilenkullanici ON public.firmalar USING btree (kullaniciadi);


--
-- Name: fki_urunler_firmalar; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_urunler_firmalar ON public.urunler USING btree (firma);


--
-- Name: fki_urunler_kategoriler; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_urunler_kategoriler ON public.urunler USING btree (kategori);


--
-- Name: fki_urunler_markalar; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_urunler_markalar ON public.urunler USING btree (marka);


--
-- Name: alicifirma emp_stamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER emp_stamp BEFORE INSERT OR UPDATE ON public.alicifirma FOR EACH ROW EXECUTE FUNCTION public."gelisfiyati -> satisfiyati"();


--
-- Name: onlinekullanici firmaisimdegisikligi; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER firmaisimdegisikligi BEFORE UPDATE ON public.onlinekullanici FOR EACH ROW EXECUTE FUNCTION public.firmaisimdegisikligi();


--
-- Name: firmalar kayitkontrol; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER kayitkontrol BEFORE INSERT OR UPDATE ON public.firmalar FOR EACH ROW EXECUTE FUNCTION public.kaydet();


--
-- Name: urunler urunler_firma_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.urunler
    ADD CONSTRAINT urunler_firma_fkey FOREIGN KEY (firma) REFERENCES public.firmalar(firmaid) NOT VALID;


--
-- Name: urunler urunler_kategoriler; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.urunler
    ADD CONSTRAINT urunler_kategoriler FOREIGN KEY (kategori) REFERENCES public.kategoriler(kategoriid) NOT VALID;


--
-- Name: urunler urunler_markalar; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.urunler
    ADD CONSTRAINT urunler_markalar FOREIGN KEY (marka) REFERENCES public.markalar(markaid) NOT VALID;


--
-- PostgreSQL database dump complete
--

